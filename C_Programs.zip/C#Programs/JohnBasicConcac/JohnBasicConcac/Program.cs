﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JohnBasicConcac
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num1 = 10;
            int Num2 = 5;
            int Answer;

            Console.WriteLine("Welcome to my first programme");
             
            Console.WriteLine(Num1 + Num2);
            Answer = Num1 + Num2;

           Console.WriteLine(Num1 * Num2);
            Answer = Num1 * Num2;

            //Console.WriteLine(Num1 - Num2);
            //Answer = Num1 - Num2;

            //Console.WriteLine(Num1 / Num2);
            //Answer = Num1 / Num2;



            Console.ReadKey();


        }
    }
}
